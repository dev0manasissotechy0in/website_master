
<?php $__env->startSection('title',$product->title.' : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<link rel="stylesheet" href="https://cdn.rawgit.com/sachinchoolur/lightgallery.js/master/dist/css/lightgallery.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
$breadcrumb = [];
$breadcrumb['Home'] = '/';
$breadcrumb[$product->cat_name->name] = url('product/c/'.$product->cat_name->slug);
if($product->subcat_name != null){
$breadcrumb[$product->subcat_name->name] = url('product/c/'.$product->cat_name->slug.'/'.$product->subcat_name->slug);
}
?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>$breadcrumb]); ?>
<?php $__env->slot('title'); ?> <?php echo e($product->title); ?> <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> <?php echo e($product->title); ?> <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <?php if($product->thumbnail != ''): ?>
                <img src="<?php echo e(asset('public/products/'.$product->thumbnail)); ?>" class="w-100 mb-3" alt="">
                <?php else: ?>
                <img src="<?php echo e(asset('public/products/default.png')); ?>" class="w-100 mb-3" alt="">
                <?php endif; ?>
                <ul class="list-unstyled d-flex justify-content-center">
                    <?php if($product->preview_link != ''): ?>
                    <li class="me-3"><a href="<?php echo e($product->preview_link); ?>" class="btn" target="_blank">Live Preview</a></li>
                    <?php endif; ?>
                    <?php if($product->images != ''): ?>
                    <li class="me-3"><button type="button" id="show-screenshots" class="btn">Sreenshots</button></li>
                    <?php
                    $images = array_filter(explode(',',$product->images));
                    $img_count = count($images);
                    ?>
                    <?php if($img_count > 0): ?>
                    <div id="lightgallery" class="d-none">
                        <?php for($i=0;$i<$img_count;$i++): ?>
                        <a href="<?php echo e(asset('public/products/'.$images[$i])); ?>">
                            <img src="<?php echo e(asset('public/products/'.$images[$i])); ?>" />
                        </a>
                        <?php endfor; ?>
                    </div>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php if(session()->has('user_type') && session()->get('user_type') != 'seller'): ?>
                    <?php $cart = user_cart();
                    $wishlist = user_wishlist(); ?>
                    <?php if(in_array($product->id,$cart)): ?>
                    <li class="me-3"><button data-id="<?php echo e($product->id); ?>" class="remove-cart btn">Remove From Cart</button></li>
                    <?php else: ?>
                    <li class="me-3"><button data-id="<?php echo e($product->id); ?>" class="add-cart btn">Add to Cart</button></li>
                    <?php endif; ?>
                    <?php if(in_array($product->id,$wishlist)): ?>
                    <li class="me-3"><button data-id="<?php echo e($product->id); ?>" class="remove-wishlist btn">Remove from Wishlist</button></li>
                    <?php else: ?>
                    <li class="me-3"><button data-id="<?php echo e($product->id); ?>" class="add-cart btn">Add to Wishlist</button></li>
                    <?php endif; ?>
                    <?php endif; ?>
                </ul>
                <?php echo htmlspecialchars_decode($product->desc); ?>

                <div class="page-widget border p-4 mb-4">
                    <h4>Reviews</h4>
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="review-box border">
                        <div class="user-info d-flex mb-2">
                            <div class="user-img">
                                <img src="<?php echo e(asset('public/users/default.png')); ?>" alt="" width="50px">
                            </div>
                            <h6 class="align-self-center m-0"><?php echo e($review->name); ?></h6>
                        </div>
                        <ul class="rating d-flex list-unstyled mb-2">
                            <?php for($i=1;$i<=5;$i++): ?>
                            <li><i class="bi <?php if($review->rating >= $i): ?> bi-star-fill <?php else: ?> bi-star <?php endif; ?>"></i></li>
                            <?php endfor; ?>
                        </ul>
                        <p><?php echo e(htmlspecialchars_decode($review->feedback)); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="page-widget border p-4 mb-4">
                    <h4>Product Information</h4>
                    <ul class="list-unstyled mb-0">
                        <li class="d-flex justify-content-between">
                            <span>Last Update</span>
                            <span class="w-auto"><?php echo e(date('d M, Y',strtotime($product->updated_at))); ?></span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <span>Release Date</span>
                            <span class="w-auto"><?php echo e(date('d M, Y',strtotime($product->created_at))); ?></span>
                        </li>
                        <li class="d-flex justify-content-between">
                            <span>Category</span>
                            <span class="w-auto">
                                <a href="<?php echo e(url('product/c/'.$product->cat_name->slug)); ?>"><?php echo e($product->cat_name->name); ?></a>, 
                                <?php if($product->subcat_name != null): ?>
                                <a href="<?php echo e(url('product/c/'.$product->cat_name->slug.'/'.$product->subcat_name->slug)); ?>"><?php echo e($product->subcat_name->name); ?></a>
                                <?php endif; ?>
                            </span>
                        </li>
                        <?php if($product->tags != ''): ?>
                        <?php
                        $tag_names = array_filter(explode(',',$product->tag_list));
                        $tag_slugs = array_filter(explode(',',$product->tag_slugs));
                        $count_tags = count($tag_names);
                        ?>
                        <li class="d-flex justify-content-between">
                            <span>Tags</span>
                            <span class="w-auto">
                                <?php for($i=0;$i<$count_tags;$i++): ?>
                                <a href="<?php echo e(url('product/tag/'.$tag_slugs[$i])); ?>"><?php echo e($tag_names[$i]); ?></a><?php if($i < $count_tags-1 ): ?>,<?php endif; ?>
                                <?php endfor; ?>
                            </span>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="page-side-widget text-center">
                    <div class="user-img rounded-circle overflow-hidden">
                        <?php if($product->author->image != ''): ?>
                        <img src="<?php echo e(asset('public/users/'.$product->author->image)); ?>" alt="">
                        <?php else: ?>
                        <img src="<?php echo e(asset('public/users/default.png')); ?>" alt="">
                        <?php endif; ?>
                    </div>
                    <h4 class="user-name"><?php echo e($product->author->name); ?></h4>
                    <span>Member Since <?php echo e(date('M Y',strtotime($product->author->created_at))); ?></span>
                    <a href="<?php echo e(url('seller/'.$product->author->slug)); ?>" class="btn d-block">View Profile</a>
                </div>
                
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="https://cdn.rawgit.com/sachinchoolur/lightgallery.js/master/dist/js/lightgallery.js"></script> 
<script>
    lightGallery(document.getElementById('lightgallery'));

$("#show-screenshots").on("click", () => {
    $("#lightgallery a:first-child > img").trigger("click");
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/product_single.blade.php ENDPATH**/ ?>