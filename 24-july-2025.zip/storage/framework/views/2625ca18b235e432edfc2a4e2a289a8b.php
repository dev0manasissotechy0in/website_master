
<?php $__env->startSection('title','Payment Settings : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<style>
  .custom-checkbox{
    /* display: inline-block; */
    /* vertical-align: bottom; */
    position: relative; 
  }
  .custom-checkbox input[type=checkbox]{
      margin: 0;
      visibility: hidden;
      position: absolute;
      left: 1px;
      top: 1px;
  }
  .custom-checkbox label{
      width: 66px;
      height: 24px;
      border: 2px solid #706d92;
      cursor: pointer;
      border-radius: 10px;
      overflow: hidden;
      display: block;
      position: relative;
      z-index: 1;
      transition: all 0.3s ease;
  }
  .custom-checkbox label:before{
      content: '';
      background: #706d92;
      border-radius: 50px;
      width: 16px;
      height: 16px;
      position: absolute;
      bottom: 2px;
      left: 2px;
      transition: all 0.3s ease;
  }
  .custom-checkbox label:after{
    content: 'hide';
    color: '706d92';
    font-size: 14px;
    font-weight: 700;
    text-transform: capitalize;
    position: absolute;
    left: 22px;
    top: 0;
  }
  .custom-checkbox input[type=checkbox]:checked+label{
      background: #7338ba;
      border: 2px solid #7338ba;
  }
  .custom-checkbox input[type=checkbox]:checked+label:before{
      background: #fff;
      left: 44px;
  }

  .custom-checkbox input[type=checkbox]:checked+label:after{
    content: 'Show';
    color: #fff;
    left: 2px;
  }

  @media only screen and (max-width:767px){
      .custom-checkbox{ margin: 0 0 20px; }
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <?php $__env->startComponent('admin.partials.page-head',['breadcrumb'=>['Dashboard'=>'/admin/dashboard']]); ?>
        <?php $__env->slot('title'); ?> Payment Settings <?php $__env->endSlot(); ?>
        <?php $__env->slot('add_btn'); ?> <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Payment Settings <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body py-3">
                        <form class="g-3 needs-validation" id="updatePaymentSettings">
                          <?php echo csrf_field(); ?>
                          <div class="row">
                            <div class="form-group col-md-12 mb-3">
                              <label class="form-label">Commission (in %)</label>
                              <input type="number" class="form-control" name="commission" required value="<?php echo e($payment->commission); ?>">
                            </div>
                            <div class="form-group col-md-12 mb-3">
                              <label class="form-label">Tax Percentage (in %)</label>
                              <input type="number" class="form-control" name="tax_percent" required value="<?php echo e($payment->tax_percent); ?>">
                            </div>
                          </div>
                            <div class="col-12">
                              <button class="btn btn-primary" type="submit">Update</button>
                            </div>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.validate.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/admin/settings/payment.blade.php ENDPATH**/ ?>