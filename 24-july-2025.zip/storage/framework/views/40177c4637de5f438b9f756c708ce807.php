
<?php $__env->startSection('title','Withdraw Methods : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datatables.net-bs5/1.13.8/dataTables.bootstrap5.min.css" />
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <?php $__env->startComponent('admin.partials.page-head',['breadcrumb'=>['Dashboard'=>'/admin/dashboard']]); ?>
        <?php $__env->slot('title'); ?> Withdraw Methods <?php $__env->endSlot(); ?>
        <?php $__env->slot('add_btn'); ?> <a href="<?php echo e(url('admin/withdraw-methods/create')); ?>" class="btn btn-primary btn-sm rounded-pill align-self-center">+ Add New</a>  <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Withdraw Methods <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body py-4">
                        <!-- show data table component -->
                    <?php $__env->startComponent('admin.partials.dataTables',['thead'=>
                        ['S NO.','Name','Charge(%)','Status','Action']
                    ]); ?>
                        <?php $__env->slot('table_id'); ?> method-list <?php $__env->endSlot(); ?>
                    <?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.dataTables.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables.net-bs5/1.13.8/dataTables.bootstrap5.min.js"></script>
<script src="<?php echo e(asset('public/assets/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/responsive.bootstrap4.min.js')); ?>"></script>

<script type="text/javascript">
    var table = $("#method-list").DataTable({
        processing: true,
        serverSide: true,
        ajax: "withdraw-methods",
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex',sWidth: '50px'},
            {data: 'name', name: 'name'},
            {data: 'charge', name: 'charge',sWidth: '50px'},
            {data: 'status', name: 'status',sWidth: '50px'},
            {
                data: 'action',
                name: 'action',
                orderable: true,
                searchable: true,
                sWidth: '100px'
            }
        ]
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/admin/withdraw-method/index.blade.php ENDPATH**/ ?>