
<?php $__env->startSection('title','Products : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php if(Request::get('s') != ''): ?>
    <?php $__env->slot('title'); ?> Search : <?php echo e(Request::get('s')); ?> <?php $__env->endSlot(); ?>
<?php else: ?>
    <?php $__env->slot('title'); ?> Products <?php $__env->endSlot(); ?>
<?php endif; ?>
<?php $__env->slot('active'); ?> Products <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-9 row">
                <?php if($products->total() > $products->perPage()): ?>
                <div class="col-12 page-widget border p-3 mb-4">
                    <?php echo e($products->links()); ?>

                </div>
                <?php endif; ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 mb-4">
                    <?php echo $__env->make('public.partials.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($products->total() > $products->perPage()): ?>
                <div class="col-12 page-widget border p-3 mb-4">
                    <?php echo e($products->links()); ?>

                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-3">
                <div class="page-widget border p-4 mb-4">
                    <h4>Search</h4>
                    <form action="<?php echo e(url()->current()); ?>" class="row">
                        <div class="d-flex field-group position-relative">
                            <input type="text" class="form-control rounded-0" name="s" value="<?php if(Request::get('s') != ''): ?><?php echo e(Request::get('s')); ?> <?php endif; ?>"required >
                            <button class="btn" type="submit"><i class="bi bi-search"></i></button>
                          </div>
                    </form>
                </div>
                <div class="page-widget border p-4 mb-4">
                    <h4>Categories</h4>
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cat->products_count > 0): ?>
                        <li><a href="<?php echo e(url('/product/c/'.$cat->slug)); ?>"><?php echo e($cat->name); ?></a></li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/all-products.blade.php ENDPATH**/ ?>