
<?php $__env->startSection('title','Product Reviews : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> Product Reviews <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> Product Reviews <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="product-single d-flex">
                    <?php if($product->thumbnail != ''): ?>
                    <img src="<?php echo e(asset('public/products/'.$product->thumbnail)); ?>" alt="">
                    <?php else: ?>
                    <img src="<?php echo e(asset('public/products/default.png')); ?>" alt="">
                    <?php endif; ?>
                    <div class="product-content flex-grow-1">
                        <h3><a href="<?php echo e(url('product/'.$product->slug)); ?>"><?php echo e($product->title); ?></a></h3>
                        <span>Price : <?php echo e(cur_format()); ?><?php echo e($product->price); ?></span>
                        <?php $product_rating = product_rating($product->id);  ?>
                        <ul class="rating d-flex list-unstyled">
                            <?php $rating = 0;  ?>
                            <?php if($product_rating->rating_col > 0): ?>
                                <?php $rating = ceil($product_rating->rating_sum/$product_rating->rating_col);  ?>  
                            <?php endif; ?>
                            <?php for($i=1;$i<=5;$i++): ?>
                                <?php if($i <= $rating): ?>
                                <li><i class="bi bi-star-fill"></i></li>
                                <?php else: ?>
                                <li><i class="bi bi-star"></i></li>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </ul>
                    </div>
                </div>
                <form id="submit-review" class="position-relative mb-5">
                    <span>Choose Star Rating</span>
                    <div class="form-group rating-stars">
                        <div class="rate mb-2">
                            <input type="radio" id="star5" class="rate" name="rating" value="5"/>
                            <label for="star5" title="5 Stars">5 stars</label>
                            <input type="radio" id="star4" class="rate" name="rating" value="4"/>
                            <label for="star4" title="4 Stars">4 stars</label>
                            <input type="radio" id="star3" class="rate" name="rating" value="3"/>
                            <label for="star3" title="3 Stars">3 stars</label>
                            <input type="radio" id="star2" class="rate" name="rating" value="2">
                            <label for="star2" title="2 Stars">2 stars</label>
                            <input type="radio" id="star1" class="rate" name="rating" value="1"/>
                            <label for="star1" title="1 Stars">1 star</label>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="">Add Review</label>
                        <textarea name="review" class="form-control"></textarea>
                    </div>
                    <input type="submit" class="btn" value="Submit">
                </form>
                <?php if($reviews->isNotEmpty()): ?>
                <div class="page-widget border p-4 mb-4">
                    <h4>Reviews</h4>
                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="review-box border">
                        <div class="user-info d-flex mb-2">
                            <div class="user-img">
                                <img src="<?php echo e(asset('public/users/default.png')); ?>" alt="" width="50px">
                            </div>
                            <h6 class="align-self-center m-0"><?php echo e($review->name); ?></h6>
                        </div>
                        <ul class="rating d-flex list-unstyled mb-2">
                            <?php for($i=1;$i<=5;$i++): ?>
                            <li><i class="bi <?php if($review->rating >= $i): ?> bi-star-fill <?php else: ?> bi-star <?php endif; ?>"></i></li>
                            <?php endfor; ?>
                        </ul>
                        <p><?php echo e(htmlspecialchars_decode($review->feedback)); ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php else: ?>
                <span>No Reviews Found</span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/product-reviews.blade.php ENDPATH**/ ?>