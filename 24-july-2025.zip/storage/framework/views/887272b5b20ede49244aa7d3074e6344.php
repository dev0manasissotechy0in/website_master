
<?php $__env->startSection('title','Add New Testimonials : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <?php $__env->startComponent('admin.partials.page-head',['breadcrumb'=>['Dashboard'=>'/admin/dashboard','Testimonials'=>'admin/testimonials']]); ?>
        <?php $__env->slot('title'); ?> Create Testimonial <?php $__env->endSlot(); ?>
        <?php $__env->slot('add_btn'); ?> <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Create <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body py-3">
                        <form class="g-3 needs-validation" id="addTestimonial">
                          <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                              <label class="form-label">Client Name</label>
                              <input type="text" class="form-control" name="client_name" required>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Client Designation</label>
                              <input type="text" class="form-control" name="client_designation" required>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Feedback</label>
                              <textarea name="feedback" class="form-control" required></textarea>
                            </div>
                            <div class="form-group mb-3">
                                <label class="form-label">Client Image</label>
                                <input type="file" class="form-control mb-2" name="image" onChange="readURL(this);">
                                <img id="image" src="<?php echo e(asset('public/testimonials/default.png')); ?>" width="100px">
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Status</label>
                              <select name="status" class="form-control">
                                <option value="1" selected>Active</option>
                                <option value="0">Inactive</option>
                              </select>
                            </div>
                            <div class="col-12">
                              <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/image-uploader.js')); ?>"></script>
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/admin/testimonials/create.blade.php ENDPATH**/ ?>