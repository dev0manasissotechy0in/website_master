
<?php $__env->startSection('title','Checkout : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> Checkout <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> Checkout <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form id="checkout">
                <div class="page-widget border p-4 mb-3">
                    <h4>Products List</h4>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>S.No.</th>
                                <th>Image</th>
                                <th>Product Name</th>
                                <th>Product Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i=0; $total = 0; ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; $total += $product->price; ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td>
                                    <?php if($product->image != ''): ?>
                                    <img src="<?php echo e(asset('public/products/default.jpg')); ?>" alt="" width="50px">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('public/products/'.$product->thumbnail)); ?>" alt="" width="50px">
                                    <?php endif; ?>
                                    <input type="text" hidden name="item[]" value="<?php echo e($product->id); ?>">
                                </td>
                                <td><?php echo e($product->title); ?></td>
                                
                                <td><?php echo e(cur_format()); ?><?php echo e($product->price); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="3" align="right"><b>Total</b></td>
                                <th><?php echo e(cur_format()); ?><?php echo e($total); ?></th>
                            </tr>
                            <?php  $tax_amt = ceil($total*tax_percent()/100); ?>
                            <tr>
                                <td colspan="3" align="right">Tax(<?php echo e(tax_percent()); ?>%)</td>
                                <th><?php echo e(cur_format()); ?><?php echo e($tax_amt); ?></th>
                            </tr>
                            <tr>
                                <td colspan="3" align="right"><b>Grand Total</b></td>
                                <th><?php echo e(cur_format()); ?><?php echo e($total+$tax_amt); ?>

                                <input type="text" hidden name="total_amount" class="total-amount" value="<?php echo e($total+$tax_amt); ?>"> 
                                <input type="text" hidden name="amount" value="<?php echo e($total); ?>"> 
                                <input type="text" hidden name="tax_amount" value="<?php echo e($tax_amt); ?>"> 
                                </th>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="page-widget border p-4 mb-4">
                    <h4>Payment Method</h4>
                    <ul class="list-unstyled d-flex">
                        <?php $gateways = payment_gateway_list();  ?>
                        <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gateway): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="me-4">
                            <input type="radio" id="pay<?php echo e($gateway->id); ?>" name="pay_method" value="<?php echo e($gateway->name); ?>" <?php if($gateway->name == 'razorpay'): ?> checked <?php endif; ?> required>
                            <label for="pay<?php echo e($gateway->id); ?>"><img src="<?php echo e(asset('public/payment/'.$gateway->image)); ?>" width="100px"></label>
                            <?php if($gateway->name == 'razorpay'): ?>
                            <input type="text" hidden name="razor_key" value="<?php echo e(env('RAZOR_KEY')); ?>">
                            <?php endif; ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <button type="button" class="btn confirm-order">Confirm Order</button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="https://checkout.razorpay.com/v1/checkout.js" type="text/javascript"></script>
<script>
    // $('.confirm-order').click(function(){
    //     alert($('#checkout').serialize());
    // });
    $(function(){
        var uRL = $('.site-url').val();

          
            $(document).on('click','.confirm-order',function(){
                var amount = $('.total-amount').val();
                var method = $('input[name=pay_method]:checked').val();
                if(method == undefined || method == ''){
                    Swal.fire({
                        icon: 'warning',
                        title: 'Select Payment Method',
                        showConfirmButton: false,
                        timer: 1500
                    })
                }else{
                    if(method == 'paypal'){
                        var formdata = $('#checkout').serialize();
                        // console.log(formdata);
                        window.location.href = uRL+'/pay-with-paypal/?'+formdata;
                    }else{
                        var tr = '';
                        var razorpay = new Razorpay({
                            key: $('input[name=razor_key]').val(),
                            amount: amount*100, 
                            name: 'Digital Product Purchase',
                            order_id: '',
                            handler: function (transaction) {
                                tr = transaction.razorpay_payment_id;
                                var formdata = $('#checkout').serialize()+'&razor_payId='+tr;
                                window.location.href = uRL+'/pay-with-razorpay?'+formdata;
                            }
                        });
                        razorpay.open();
                    }
                }
                
            })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/checkout.blade.php ENDPATH**/ ?>