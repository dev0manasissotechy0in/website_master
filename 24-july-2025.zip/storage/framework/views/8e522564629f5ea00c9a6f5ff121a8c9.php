
<?php $__env->startSection('title','My Wallet : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> My Wallet <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> My Wallet <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-widget">
                    <h4>Available Balance : <?php echo e(cur_format()); ?><?php echo e(seller_balance(session()->get('user_sess'))); ?></h4>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>Date</th>
                            <th>Deposit</th>
                            <th>Withdraw</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e(date('d M, Y',strtotime($row->created_at))); ?></td>
                            <td><?php if($row->type == 'credit'): ?> 
                                <?php echo e(cur_format()); ?><?php echo e($row->amount); ?> <?php endif; ?></td>
                            <td><?php if($row->type == 'debit'): ?> <?php echo e(cur_format()); ?> <?php echo e($row->amount); ?> <?php endif; ?>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/frontend/js/product.js')); ?>"></script>
<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $(function(){
        $('.product-images').imageUploader({
            imagesInputName: 'images',
            'label': 'Drag & Drop files here or click to browse' 
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/seller-wallet.blade.php ENDPATH**/ ?>