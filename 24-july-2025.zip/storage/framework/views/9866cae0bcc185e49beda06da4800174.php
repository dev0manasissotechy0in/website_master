<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?><?php echo e(site_name()); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/bootstrap.min.css')); ?>">
    <link href="<?php echo e(asset('public/assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.2/dist/sweetalert2.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('public/frontend/css/image-uploader.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('pageStyleLinks'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/style.css')); ?>">
</head>
<body>
    <div id="wrapper">
        <header id="header">
            <div class="header-topbar">
                <div class="container d-flex justify-content-between">
                <ul class="header-social d-flex list-unstyled m-0">
                    <?php $social_links = social_links(); ?>
                    <?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e($social->link); ?>" target="_blank"><i class="<?php echo e($social->icon); ?>"></i></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <ul class="topbar-right d-flex list-unstyled m-0 align-self-center">
                    <?php if(session()->has('user_sess')): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle p-0" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Profile
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="<?php echo e(url('user-profile')); ?>"><i class="bi bi-person"></i> My Profile</a></li>
                            <?php if(session()->get('user_type') == 'seller' && approved_seller()): ?>
                            <li><a class="dropdown-item" href="<?php echo e(url('create-product')); ?>"><i class="bi bi-plus-square"></i> Add Product</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('my-products')); ?>"><i class="bi bi-boxes"></i> My Products</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('withdraw-requests')); ?>"><i class="bi bi-arrow-down-square"></i> Withdraw Request</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(url('seller-wallet')); ?>"><i class="bi bi-arrow-down-square"></i> My Wallet</a></li>
                            <?php endif; ?>
                            <?php if(session()->get('user_type') == 'user'): ?>
                            <li><a class="dropdown-item" href="<?php echo e(url('my-downloads')); ?>"><i class="bi bi-download"></i> My Downloads</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="<?php echo e(url('change-password')); ?>"><i class="bi bi-pencil"></i> Change Password</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(url('logout')); ?>"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo e(url('login')); ?>"><i class="bi bi-box-arrow-in-right"></i> Login</a></li>
                    <li><a href="<?php echo e(url('signup')); ?>"><i class="bi bi-person-add"></i> Register</a></li>
                    <?php endif; ?>
                </ul>
                </div>
            </div>
            <div class="logobar py-4">
                <div class="container d-flex justify-content-between">
                    <a href="<?php echo e(url('/')); ?>" class="logo">
                        <img src="<?php echo e(asset('public/settings/logo.png')); ?>" alt="">
                    </a>
                    <ul class="logobar-right d-flex list-unstyled m-0 align-self-center">
                        <?php if(!session()->has('user_type') || session()->get('user_type') != 'seller'): ?>
                        <li><a href="<?php echo e(url('my-wishlist')); ?>"><i class="bi bi-heart-fill"></i><span class="count-badge"><?php echo e(wishlist_count()); ?></span></a></li>
                        <li><a href="<?php echo e(url('my-cart')); ?>"><i class="bi bi-basket-fill"></i><span class="count-badge"><?php echo e(cart_count()); ?></span></a></li>
                        <?php endif; ?>
                        <?php if(session()->has('user_sess') != 'seller'): ?>
                        <li class="selling"><a href="<?php echo e(url('seller-signup')); ?>"><i class="bi bi-plus"></i>Start Selling</a></li>
                        <?php endif; ?>
                        <?php if(session()->get('user_type') == 'seller' && approved_seller()): ?>
                        <li class="selling"><a href="<?php echo e(url('create-product')); ?>">+ Add Product</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <nav class="navbar navbar-expand-lg navbar-light p-0">
                <div class="container">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('blogs')); ?>">Blog</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('all-products')); ?>">Products</a>
                            </li>
                            <?php $pages = custom_pages(); ?>
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page->show_in_header == '1'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url($page->slug)); ?>"><?php echo e($page->title); ?></a>
                            </li>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </nav>
        </header>
        <?php echo $__env->yieldContent('content'); ?>
        <footer id="footer" class="pt-5">
            <div class="container">
                <div class="row">
                    <?php $settings = settings(); ?>
                    <div class="col-md-3">
                        <div class="footer-widget mb-5">
                            <h5><?php echo e(site_name()); ?></h5>
                            <p><?php echo e($settings->site_desc); ?></p>
                            <ul class="footer-social">
                                <?php $__currentLoopData = $social_links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e($social->link); ?>"><i class="<?php echo e($social->icon); ?>"></i></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="footer-widget ps-4 mb-5">
                            <h5>Useful Links</h5>
                            <ul>
                                <li><a href="<?php echo e(url('login')); ?>"><i class="bi bi-arrow-right-circle"></i> Login</a></li>
                                <li><a href="<?php echo e(url('signup')); ?>"><i class="bi bi-arrow-right-circle"></i> Register</a></li>
                                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page->show_in_footer == '1'): ?>
                                <li><a href="<?php echo e(url($page->slug)); ?>"><i class="bi bi-arrow-right-circle"></i> <?php echo e($page->title); ?></a></li>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="footer-widget mb-5">
                            <h5>Categories</h5>
                            <ul>
                                <?php $categories = product_categories();  ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('product/c/'.$cat->slug)); ?>"><?php echo e($cat->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="footer-widget mb-5">
                            <h5>Contact</h5>
                            <ul class="contact-info">
                                <?php if($settings->show_contact == '1'): ?>
                                <li><i class="bi bi-telephone-fill"></i> <?php echo e($settings->site_contact); ?></li>
                                <?php endif; ?>
                                <?php if($settings->show_email == '1'): ?>
                                <li><i class="bi bi-envelope"></i> <?php echo e($settings->site_email); ?></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-bottom text-center py-3">
                <span><?php echo e(copyright_text()); ?></span>
            </div>
        </footer>
    </div>
    <script src="<?php echo e(asset('public/frontend/js/bootstrap5.0.2.min.js')); ?>"></script>
    <input type="text" hidden class="site-url" value="<?php echo e(url('/')); ?>">
    <script src="<?php echo e(asset('public/frontend/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/jquery.validate.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.2/dist/sweetalert2.all.min.js"></script>
    <script src="<?php echo e(asset('public/frontend/js/image-uploader.js')); ?>"></script>
    <script src="<?php echo e(asset('public/frontend/js/action.js')); ?>"></script>
    <?php echo $__env->yieldContent('pageJsScripts'); ?>
</body>
</html><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/public/layout/layout.blade.php ENDPATH**/ ?>