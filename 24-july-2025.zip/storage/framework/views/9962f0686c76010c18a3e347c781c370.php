
<?php $__env->startSection('title',$blog->title.' : '); ?>
<?php $__env->startSection('content'); ?>
<?php
$breadcrumb = [];
$breadcrumb['Home'] = url('/');
$breadcrumb['Blogs'] = url('blogs');
$breadcrumb[$blog->cat_name->name] = url('blogs/c/'.$blog->cat_name->slug);
?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>$breadcrumb]); ?>
<?php $__env->slot('title'); ?> <?php echo e($blog->title); ?> <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> <?php echo e($blog->title); ?> <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <?php if($blog->image != ''): ?>
                <img src="<?php echo e(asset('public/blogs/'.$blog->image)); ?>" class="w-100 mb-3" alt="">
                <?php else: ?>
                <img src="<?php echo e(asset('public/blogs/default.png')); ?>" class="w-100 mb-3" alt="">
                <?php endif; ?>
                <?php echo htmlspecialchars_decode($blog->desc); ?>

            </div>
            <div class="col-md-4">
                <div class="page-widget border p-4 mb-4">
                    <h4>Categories</h4>
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($cat->blogs_count > 0): ?>
                                <li><a href="<?php echo e(url('/blogs/c/'.$cat->slug)); ?>"><?php echo e($cat->name); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="page-widget border p-4 mb-4">
                    <h4>Related</h4>
                    <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post-box d-flex flex-row">
                        <?php if($row->image != ''): ?>
                            <img src="<?php echo e(asset('public/blogs/'.$row->image)); ?>" alt="">
                        <?php else: ?>
                            <img src="<?php echo e(asset('public/blogs/default.jpg')); ?>" alt="">
                        <?php endif; ?>
                        <div class="flex-grow-1">
                            <h5><a href="<?php echo e(url('blog/'.$row->slug)); ?>"><?php echo e(substr($row->title,0,40).'...'); ?></a></h5>
                            <a href="<?php echo e(url('blog/'.$row->slug)); ?>">Read More</a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/public/blog-single.blade.php ENDPATH**/ ?>