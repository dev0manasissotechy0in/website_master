<div class="product-grid d-flex flex-column">
    <?php if(Request::url() == url('my-wishlist')): ?>
    <button type="button" class="overlay-btn remove-wishlist" data-id="<?php echo e($product->id); ?>"><i class="bi bi-x"></i></button>
    <?php endif; ?>
    <div class="product-img">
        <?php if($product->featured == '1'): ?>
        <span class="featured-badge"><i class="bi bi-star-fill"></i></span>
        <?php endif; ?>
        <a href="<?php echo e(url('product/'.$product->slug)); ?>" class="image d-block">
            <?php if($product->thumbnail != ''): ?>
            <img src="<?php echo e(asset('public/products/'.$product->thumbnail)); ?>" alt="" class="w-100">
            <?php else: ?>
            <img src="<?php echo e(asset('public/products/default.png')); ?>" alt="" class="w-100">
            <?php endif; ?>
        </a>
        <ul class="product-links d-flex list-unstyled">
            <?php if(!session()->has('user_type') || session()->get('user_type') != 'seller'): ?>
            <?php if(session()->has('user_sess')): ?>
            <?php $wishlist = user_cart(); ?>
            <li class="<?php if(in_array($product->id,$wishlist)): ?> active <?php endif; ?>"><a href="javascript:void(0);" data-id="<?php echo e($product->id); ?>" class="add-wishlist" ><i class="bi bi-heart-fill"></i></a></li>
            <?php else: ?>
            <li><a href="<?php echo e(url('login')); ?>" ><i class="bi bi-heart-fill"></i></a></li>
            <?php endif; ?>
            <?php $cart = user_cart(); ?>
            <li class="<?php if(in_array($product->id,$cart)): ?> active <?php endif; ?>"><a href="javascript:void(0);" data-id="<?php echo e($product->id); ?>" class="add-cart"><i class="bi bi-basket-fill"></i></a></li>
            <?php endif; ?>
            <li><a href="<?php echo e(url('product/'.$product->slug)); ?>"><i class="bi bi-eye-fill"></i></a></li>
        </ul>
        <span class="product-category"><a href="<?php echo e(url('product/c/'.$product->cat_name->slug)); ?>"><?php echo e($product->cat_name->name); ?></a></span>
    </div>
    <div class="product-content">
        <h3 class="title"><a href="<?php echo e(url('product/'.$product->slug)); ?>"><?php echo e(substr($product->title,0,45).'...'); ?></a></h3>
        <div class="d-flex justify-content-between">
            <?php $product_rating = product_rating($product->id);  ?>
            <ul class="rating d-flex list-unstyled">
                <?php $rating = 0;  ?>
                <?php if($product_rating->rating_col > 0): ?>
                    <?php $rating = ceil($product_rating->rating_sum/$product_rating->rating_col);  ?>  
                <?php endif; ?>
                <?php for($i=1;$i<=5;$i++): ?>
                    <?php if($i <= $rating): ?>
                    <li><i class="bi bi-star-fill"></i></li>
                    <?php else: ?>
                    <li><i class="bi bi-star"></i></li>
                    <?php endif; ?>
                <?php endfor; ?>
            </ul>
            <div class="product-price">$<?php echo e($product->price); ?></div>
        </div>
    </div>
    <div class="product-author d-flex justify-content-between mt-auto">
        <div class="author-info d-flex">
            <div class="author-img">
                <?php if($product->author->image != ''): ?>
                <img src="<?php echo e(asset('public/users/'.$product->author->image)); ?>" alt="">
                <?php else: ?>
                <img src="<?php echo e(asset('public/users/default.png')); ?>" alt="">
                <?php endif; ?>
            </div>
            <span class="align-self-center"><a href="<?php echo e(url('seller/'.$product->author->user_name)); ?>"><?php echo e($product->author->slug); ?></a></span>
        </div>
        <span class="sales-count align-self-center"><i class="bi bi-basket-fill"></i> <?php echo e($product->downloads_count); ?></span>
    </div>
</div><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/partials/product.blade.php ENDPATH**/ ?>