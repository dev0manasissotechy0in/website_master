
<?php $__env->startSection('title',$page->title.' : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> <?php echo e($page->title); ?> <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> <?php echo e($page->title); ?> <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php echo htmlspecialchars_decode($page->desc); ?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/public/custom.blade.php ENDPATH**/ ?>