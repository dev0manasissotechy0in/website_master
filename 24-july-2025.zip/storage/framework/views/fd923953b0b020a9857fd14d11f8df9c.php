
<?php $__env->startSection('title','Withdraw Requests : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> Withdraw Requests <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> Withdraw Requests <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(url('withdraw-requests/new')); ?>" class="btn mb-3">Make New Request</a>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>Request No.</th>
                            <th>Method</th>
                            <th>Amount</th>
                            <th>Charge</th>
                            <th>Final Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=0; ?>
                        <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($row->id); ?></td>
                            <td><?php echo e($row->method_name->name); ?></td>
                            <td><?php echo e($row->amount); ?></td>
                            <td><?php echo e($row->charge_amount); ?></td>
                            <td><?php echo e($row->amount - $row->charge_amount); ?></td>
                            <td>
                                <?php if($row->status == '1'): ?>
                                    <span class="text-success">Completed</span>
                                <?php else: ?>
                                    <span class="text-danger">Pending</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/frontend/js/product.js')); ?>"></script>
<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $(function(){
        $('.product-images').imageUploader({
            imagesInputName: 'images',
            'label': 'Drag & Drop files here or click to browse' 
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/withdraw-requests.blade.php ENDPATH**/ ?>