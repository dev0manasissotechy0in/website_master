<div class="pagetitle d-flex flex-row justify-content-between">
    <div>
        <h1><?php echo e($title); ?></h1>
        <nav>
            <ol class="breadcrumb">
                <?php $__currentLoopData = $breadcrumb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="breadcrumb-item"><a href="<?php echo e(url($value)); ?>"><?php echo e($key); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="breadcrumb-item active"><?php echo e($active); ?></li>
            </ol>
        </nav>
    </div>
    <?php echo e($add_btn); ?>

</div><!-- End Page Title --><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/admin/partials/page-head.blade.php ENDPATH**/ ?>