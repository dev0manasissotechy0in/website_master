
<?php $__env->startSection('title','Banner : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <?php $__env->startComponent('admin.partials.page-head',['breadcrumb'=>['Dashboard'=>'/admin/dashboard']]); ?>
        <?php $__env->slot('title'); ?> Banner <?php $__env->endSlot(); ?>
        <?php $__env->slot('add_btn'); ?> <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Banner <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body py-3">
                        <form class="g-3 needs-validation" id="updateBanner">
                          <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                              <label class="form-label">Title</label>
                              <input type="text" class="form-control" name="title" value="<?php echo e($banner->title); ?>" required>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Sub-Title</label>
                              <input type="text" class="form-control" name="sub_title" value="<?php echo e($banner->sub_title); ?>" required>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Image</label>
                              <input type="file" name="image" class="form-control" onChange="readURL(this);" />
                              <?php if($banner->image != ''): ?>
                              <img id="image" class="mt-3" src="<?php echo e(asset('public/settings/'.$banner->image)); ?>" width="100px">
                              <?php else: ?>
                              <img id="image" class="mt-3" src="<?php echo e(asset('public/settings/default.jpg')); ?>" width="100px">
                              <?php endif; ?>
                            </div>
                            <div class="col-12">
                              <button class="btn btn-primary" type="submit">Update</button>
                            </div>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/image-uploader.js')); ?>"></script>
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/admin/settings/banner.blade.php ENDPATH**/ ?>