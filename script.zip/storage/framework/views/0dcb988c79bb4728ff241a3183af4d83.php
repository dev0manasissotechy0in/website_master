
<?php $__env->startSection('title','Edit Blog : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <?php $__env->startComponent('admin.partials.page-head',['breadcrumb'=>['Dashboard'=>'/admin/dashboard','Blogs'=>'admin/blogs']]); ?>
        <?php $__env->slot('title'); ?> Edit Blog <?php $__env->endSlot(); ?>
        <?php $__env->slot('add_btn'); ?> <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Edit <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body py-3">
                        
                        <form class="g-3 needs-validation" id="updateBlog">
                          <?php echo csrf_field(); ?>
                          <?php echo e(method_field('PUT')); ?>

                            <div class="form-group mb-3">
                              <label class="form-label">Title</label>
                              <input type="text" class="form-control" name="blog_title" required value="<?php echo e($blog->title); ?>">
                              <input type="text" class="id" value="<?php echo e($blog->id); ?>" hidden>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Slug</label>
                              <input type="text" class="form-control" name="blog_slug" required value="<?php echo e($blog->slug); ?>">
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Image</label>
                              <input type="text" hidden name="old_img" value="<?php echo e($blog->image); ?>">
                              <input type="file" class="form-control mb-2" name="image" onChange="readURL(this);">
                              <?php if($blog->image != ''): ?>
                                <img id="image" src="<?php echo e(asset('public/blogs/'.$blog->image)); ?>" width="100px">
                            <?php else: ?>
                                <img id="image" src="<?php echo e(asset('public/blogs/default.jpg')); ?>" width="100px">
                              <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Category</label>
                              <select name="category" class="form-control">
                                <option value="" disabled>Select Category</option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $selected = ($row->id == $blog->category) ? 'selected' : ''; ?>
                                <option value="<?php echo e($row->id); ?>" <?php echo e($selected); ?> ><?php echo e($row->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                              </select>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Description</label>
                              <textarea name="desc" class="tinymce-editor"><?php echo $blog->desc; ?></textarea>
                            </div>
                                                        <!--Official-->
                                                        <div class="form-group mb-3">
                              <label class="form-label">SEO Description</label>
                              <input type="text" class="form-control" name="seo_description" required value="<?php echo e($blog->seo_description); ?>">
                              <input type="text" class="id" value="<?php echo e($blog->id); ?>" hidden>
                            </div>
                            
                                                        <div class="form-group mb-3">
                              <label class="form-label">SEO KEYWORD</label>
                              <input type="text" class="form-control" name="seo_keyword" required value="<?php echo e($blog->seo_keyword); ?>">
                              <input type="text" class="id" value="<?php echo e($blog->id); ?>" hidden>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Status</label>
                              <select name="status" class="form-control">
                                <option value="1" <?php if($blog->status == '1'): ?> selected <?php endif; ?>>Active</option>
                                <option value="0" <?php if($blog->status == '0'): ?> selected <?php endif; ?>>Inactive</option>
                              </select>
                            </div>
                            <div class="col-12">
                              <button class="btn btn-primary" type="submit">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.validate.min.js')); ?>"></script>
<script>
  function readURL(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            $('#image').attr('src', e.target.result);
        }
        reader.readAsDataURL(input.files[0]); // convert to base64 string
    }
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/admin/blog/edit.blade.php ENDPATH**/ ?>