
<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/owl.theme.default.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="banner-section" style="background-image: url('public/settings/<?php echo e($banner->image); ?>');">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="banner-content">
                    <h1><?php echo e($banner->title); ?></h1>
                    <?php if($banner->sub_title != ''): ?>
                    <h3><?php echo e($banner->sub_title); ?></h3>
                    <?php endif; ?>
                    <form action="<?php echo e(url('search')); ?>" class="row">
                        <div class="d-flex field-group p-1 bg-white col-xl-8 mx-auto position-relative">
                            <input type="text" class="form-control search-input" name="s" required autocomplete="off" placeholder="Search Products">
                            <button class="btn" type="submit"><i class="bi bi-search"></i></button>
                            <div class="search-autocomplete"></div>
                          </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__currentLoopData = $home_sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($section->section_name == 'Featured Products'): ?>
<section id="featured-section" class="py-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="section-head">
                    <h2><?php echo e($section->section_title); ?></h2>
                    <?php if($section->section_desc != ''): ?>
                    <span><?php echo e($section->section_desc); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="owl-carousel owl-theme featured-carousel">
            <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <?php echo $__env->make('public.partials.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</section>
<?php endif; ?>
<?php if($section->section_name == 'Latest Products'): ?>
<section id="latest-section" class="py-5">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="section-head">
                    <h2><?php echo e($section->section_title); ?></h2>
                    <?php if($section->section_desc != ''): ?>
                    <span><?php echo e($section->section_desc); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="owl-carousel owl-theme latest-carousel">
            <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <?php echo $__env->make('public.partials.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</section>
<?php endif; ?>
<?php if($section->section_name == 'Blog Section' && $blogs->isNotEmpty()): ?>
<section id="blog-section" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-head">
                    <h2><?php echo e($section->section_title); ?></h2>
                    <?php if($section->section_desc != ''): ?>
                    <span><?php echo e($section->section_desc); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('public.partials.blog',['blog'=>$blog], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 text-center">
                <a href="<?php echo e(url('blogs')); ?>" class="btn">Show All</a>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php if($section->section_name == 'Newsletter'): ?>
<section id="newsletter-section" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="newsletter-content text-center">
                    <i class="far fa-envelope"></i>
                    <h3><?php echo e($section->section_title); ?></h3>
                    <?php if($section->section_desc != ''): ?>
                    <p><?php echo e($section->section_desc); ?></p>
                    <?php endif; ?>
                    <div class="form-group d-flex">
                        <input type="email" class="form-control news-email" required/>
                        <button class="btn subscribe-now">Subscribe</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<section id="testimonial-section" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-head">
                    <h2>Testimonials</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div id="testimonial-slider" class="owl-carousel owl-theme">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="testimonial">
                        <p class="description">
                            <i class="bi bi-quote"></i>
                            <?php echo e($feedback->client_feedback); ?>

                        </p>
                        <div class="testimonial-content d-flex justify-content-center">
                            <div class="pic">
                                <?php if($feedback->client_image != ''): ?>
                                <img src="<?php echo e(asset('public/testimonials/'.$feedback->client_image)); ?>">
                                <?php else: ?>
                                <img src="<?php echo e(asset('public/testimonials/default.png')); ?>">
                                <?php endif; ?>
                            </div>
                            <div class="justify-content-start align-self-center">
                                <h3 class="title"><?php echo e($feedback->client_name); ?></h3>
                                <span><?php echo e($feedback->client_designation); ?></span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/frontend/js/owl.carousel.min.js')); ?>"></script>
<script>
    $('.latest-carousel').owlCarousel({
        loop:false,
        margin:15,
        nav:true,
        dots:false,
        responsive:{
            0:{ items:1 },
            500:{ items:2 },
            700:{ items:3 },
            1000:{ items:4 },
            1200:{ items:5 }
        }
    })

    $('.featured-carousel').owlCarousel({
        loop:false,
        margin:15,
        nav:true,
        dots:false,
        responsive:{
            0:{ items:1 },
            500:{ items:2 },
            700:{ items:3 },
            1200:{ items:4 }
        }
    })

    $("#testimonial-slider").owlCarousel({
        loop:false,
        margin:0,
        nav:false,
        dots:true,
        responsive:{
            0:{ items:1 },
            500:{ items:1 },
            700:{ items:2 },
            1200:{ items:2 }
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/index.blade.php ENDPATH**/ ?>