
<?php $__env->startSection('title','Login : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> Login <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> login <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <form id="user-login" class="border p-4 pt-5 position-relative" method="POST">
                    <h3>Welcome Back!!!</h3>
                    <div class="form- mb-3">
                        <label for="">Email Address</label>
                        <input type="email" class="form-control" name="email" />
                    </div>
                    <div class="form- mb-3">
                        <label for="">Password</label>
                        <input type="password" class="form-control" name="password" />
                    </div>
                    <div class="d-flex justify-content-between mb-4">
                        <input type="submit" class="btn" value="Login" />
                        <span class="forgot-password align-self-center"><a href="<?php echo e(url('forgot-password')); ?>">forgot password?</a></span>
                    </div>
                    <div class="text-center">
                        <span class="forgot-password"><a href="<?php echo e(url('signup')); ?>">Don't have an account?</a></span>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/login.blade.php ENDPATH**/ ?>