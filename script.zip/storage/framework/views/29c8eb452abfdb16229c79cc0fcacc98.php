
<?php $__env->startSection('title','Profile : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> Profile <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> Profile <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="page-side-widget text-center">
                    <div class="user-img rounded-circle overflow-hidden">
                        <?php if($profile->image != ''): ?>
                        <img src="<?php echo e(asset('public/users/'.$profile->image)); ?>" alt="">
                        <?php else: ?>
                        <img src="<?php echo e(asset('public/users/default.png')); ?>" alt="">
                        <?php endif; ?>
                    </div>
                    <h4 class="user-name"><?php echo e($profile->name); ?></h4>
                    <span>Member Since <?php echo e(date('M Y',strtotime($profile->created_at))); ?></span>
                    <a href="<?php echo e(url('user/edit-profile')); ?>" class="btn d-block"><i class="bi bi-pencil"></i> Edit Profile</a>
                </div>
                <div class="page-widget border p-4 mb-4">
                    <h4>Contact Info</h4>
                    <ul class="list-unstyled">
                        <li><i class="bi bi-envelope"></i> <?php echo e($profile->email); ?></li>
                        <li><i class="bi bi-phone"></i> <?php echo e($profile->phone); ?></li>
                    </ul>
                </div>
                
            </div>
            <div class="col-md-9">
                <?php if($profile->type == 'seller' && $profile->approved_seller == '0'): ?>
                <div class="page-widget border p-2 mb-3 bg-danger text-white">
                    <h5 class="m-0">Your Selling Request in Progress.....</h5>
                </div>
                <?php elseif($profile->type == 'seller' && $profile->approved_seller == '1'): ?>
                <div class="page-widget border p-2 mb-3 bg-success text-white">
                    <h5 class="m-0">Your Selling Request is Approved</h5>
                </div>
                <?php endif; ?>
                <div class="page-widget border p-4 mb-3">
                    <h4>Personal Details</h4>
                    <ul class="list-unstyled">
                        <li><span>Full Name :</span> <?php echo e($profile->name); ?></li>
                        <li><span>Location :</span> <?php echo e($profile->country); ?></li>
                        <li><span>Email :</span> <?php echo e($profile->email); ?></li>
                        <li><span>Phone :</span> <?php echo e($profile->phone); ?></li>
                    </ul>
                </div>
                <?php if(session()->get('user_type') == 'seller'): ?>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card dashboard-card">
                                <i class="bi bi-cart"></i>
                                <h2 class="card-title"><?php echo e($total_sales); ?></h2>
                                <span>Total Sales</span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card dashboard-card">
                                <i class="bi bi-currency-dollar"></i>
                                <h2 class="card-title"><?php echo e($total_revenue*seller_commission()/100); ?></h2>
                                <span>Total Revenue</span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card dashboard-card">
                                <i class="bi bi-cart"></i>
                                <h2 class="card-title"><?php echo e($today_sales); ?></h2>
                                <span>Today Sales</span>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                <div class="page-widget border p-3">
                    <h4 class="m-0 mb-3">My Downloads</h4>
                    <div class="row">
                        <?php if($products->isNotEmpty()): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-3">
                                <?php echo $__env->make('public.partials.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <div class="col-12 text-center">
                            <h5>No Products Downloaded yet.</h5>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/user-profile.blade.php ENDPATH**/ ?>