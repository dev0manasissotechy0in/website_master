
<?php $__env->startSection('title', 'Create Blog : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <?php $__env->startComponent('admin.partials.page-head', [
            'breadcrumb' => ['Dashboard' => '/admin/dashboard', 'Blogs' => 'admin/blogs'],
        ]); ?>
            <?php $__env->slot('title'); ?>
                Create Blog
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('add_btn'); ?>
            <?php $__env->endSlot(); ?>
            <?php $__env->slot('active'); ?>
                Create
            <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>
        <section class="section">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body py-3">
                            
                                <form class="g-3 needs-validation" id="addBlog">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-3">
                                    <label class="form-label">Title</label>
                                    <input type="text" class="form-control" name="blog_title" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="form-label">Image (Size : 580px X 300px)</label>
                                    <input type="file" class="form-control mb-2" name="image"
                                        onChange="readURL(this);">
                                    <img id="image" src="<?php echo e(asset('public/blogs/default.jpg')); ?>" width="100px">
                                </div>
                                <div class="form-group mb-3">
                                    <label class="form-label">Category</label>
                                    <select name="category" class="form-control">
                                        <option value="" disabled selected>Select Category</option>
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="form-label">Description</label>
                                    <textarea name="desc" class="tinymce-editor"></textarea>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="form-label">SEO Description</label>
                                    <input type="text" class="form-control" name="seo_description" required>
                                </div>
                                <div class="form-group mb-3">
                                    <label class="form-label">SEO KEYWORD</label>
                                    <input type="text" class="form-control" name="seo_keyword" required>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-primary" type="submit">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
    <script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/jquery.validate.min.js')); ?>"></script>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#image').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]); // convert to base64 string
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/admin/blog/create.blade.php ENDPATH**/ ?>