
<?php $__env->startSection('title','My Downloads : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> My Downloads <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> My Downloads <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-single d-flex">
                    <?php if($product->thumbnail != ''): ?>
                    <img src="<?php echo e(asset('public/products/'.$product->thumbnail)); ?>" alt="">
                    <?php else: ?>
                    <img src="<?php echo e(asset('public/products/default.png')); ?>" alt="">
                    <?php endif; ?>
                    <div class="product-content flex-grow-1">
                        <h3><a href="<?php echo e(url('product/'.$product->slug)); ?>"><?php echo e($product->title); ?></a></h3>
                        <span>Price : <?php echo e(cur_format()); ?><?php echo e($product->price); ?></span>
                        <ul class="rating d-flex list-unstyled mb-0">
                            <li><i class="bi bi-star-fill"></i></li>
                            <li><i class="bi bi-star-fill"></i></li>
                            <li><i class="bi bi-star-fill"></i></li>
                            <li><i class="bi bi-star-fill"></i></li>
                            <li><i class="bi bi-star"></i></li>
                        </ul>
                    </div>
                    <div class="d-flex flex-column">
                        <a href="<?php echo e(url('product/'.$product->slug.'/download')); ?>" class="btn mb-2"><i class="bi bi-download"></i> Download</a>
                        <a href="<?php echo e(url('product/'.$product->slug.'/reviews')); ?>" class="btn"><i class="bi bi-star"></i> Review</a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        
        <div class="row">
            <div class="col-12">
                <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/frontend/js/product.js')); ?>"></script>
<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $(function(){
        $('.product-images').imageUploader({
            imagesInputName: 'images',
            'label': 'Drag & Drop files here or click to browse' 
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/user_downloads.blade.php ENDPATH**/ ?>