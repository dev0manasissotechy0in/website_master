
<?php $__env->startSection('title','My Products : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> My Products <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> My Products <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <ul class="nav nav-tabs mb-3" id="ex1" role="tablist">
                    <li class="nav-item" role="presentation">
                      <a class="nav-link active" id="approve-tab" data-bs-toggle="tab" href="#approve-content" role="tab" aria-controls="approve-content" aria-selected="true">Approved</a
                      >
                    </li>
                    <li class="nav-item" role="presentation">
                      <a class="nav-link" id="under-tab" data-bs-toggle="tab" href="#under-content" role="tab" aria-controls="under-content" aria-selected="false" >Under Approval</a
                      >
                    </li>
                </ul>
                <div class="tab-content" id="ex1-content">
                    <div class="tab-pane fade show active" id="approve-content" role="tabpanel" aria-labelledby="approve-tab" >
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Image</th>
                                    <th>Product Name</th>
                                    <th>Product Price</th>
                                    <th>Sales</th>
                                    <th>Approval Status</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($products->isNotEmpty()): ?>
                                <?php $i=0; ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($product->approved == '1'): ?>
                                <?php $i++; ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td>
                                        <?php if($product->image != ''): ?>
                                        <img src="<?php echo e(asset('public/products/default.jpg')); ?>" alt="" width="50px">
                                        <?php else: ?>
                                        <img src="<?php echo e(asset('public/products/'.$product->thumbnail)); ?>" alt="" width="50px">
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($product->title); ?></td>
                                    <td><?php if($product->price != ''): ?> <?php echo e(cur_format()); ?><?php echo e($product->price); ?><?php endif; ?></td>
                                    <td><?php echo e($product->downloads_count); ?></td>
                                    <td>
                                        <span class="text-success">Approved</span>
                                    </td>
                                    <td>
                                        <?php if($product->status == '1'): ?>
                                        <span class="text-success">Active</span>
                                        <?php else: ?>
                                        <span class="text-secondary">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <a class="nav-link dropdown-toggle btn btn-primary btn-sm" href="#" id="mpDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Action
                                            </a>
                                            <ul class="dropdown-menu" aria-labelledby="mpDropdown">
                                                <li><a class="dropdown-item" href="<?php echo e(url('seller/'.$product->slug.'/edit-product')); ?>">Edit</a></li>
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="6" align="center">No Products Found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="under-content" role="tabpanel" aria-labelledby="under-tab">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Image</th>
                                    <th>Product Name</th>
                                    <th>Product Price</th>
                                    <th>Approval Status</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($products->isNotEmpty()): ?>
                                <?php $i=0; ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($product->approved == '0'): ?>
                                <?php $i++; ?>
                                <tr>
                                    <td><?php echo e($i); ?></td>
                                    <td>
                                        <?php if($product->image != ''): ?>
                                        <img src="<?php echo e(asset('public/products/default.jpg')); ?>" alt="" width="50px">
                                        <?php else: ?>
                                        <img src="<?php echo e(asset('public/products/'.$product->thumbnail)); ?>" alt="" width="50px">
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($product->title); ?></td>
                                    <td><?php if($product->price != ''): ?> $<?php echo e($product->price); ?><?php endif; ?></td>
                                    <td>
                                        <span class="text-secondary">Pending</span>
                                    <td>
                                        <span class="text-secondary">Inactive</span>
                                    </td>
                                    <td></td>
                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="6" align="center">No Products Found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/frontend/js/product.js')); ?>"></script>
<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $(function(){
        $('.product-images').imageUploader({
            imagesInputName: 'images',
            'label': 'Drag & Drop files here or click to browse' 
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/user-products.blade.php ENDPATH**/ ?>