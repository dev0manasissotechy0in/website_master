
<?php $__env->startSection('title','Edit Homepage Section : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <?php $__env->startComponent('admin.partials.page-head',['breadcrumb'=>['Dashboard'=>'/admin/dashboard']]); ?>
        <?php $__env->slot('title'); ?> Homepage Settings <?php $__env->endSlot(); ?>
        <?php $__env->slot('add_btn'); ?> <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Homepage Settings <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body py-3">
                        
                          <div class="accordion" id="accordions">
                            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item mb-3">
                              <h2 class="accordion-header" id="section<?php echo e($section->id); ?>">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($section->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($section->id); ?>">
                                  <b><?php echo e($section->section_name); ?></b>
                                </button>
                              </h2>
                              <div id="collapse<?php echo e($section->id); ?>" class="accordion-collapse collapse show bg-secondary-subtle" aria-labelledby="section<?php echo e($section->id); ?>" data-bs-parent="#accordions">
                                <div class="accordion-body">
                                  <form class="g-3 needs-validation" method="POST" id="homeSection<?php echo e($section->id); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group mb-3">
                                      <label for="">Section Title</label>
                                      <input type="text" class="form-control" name="section_title" value="<?php echo e($section->section_title); ?>" required>
                                      <input type="text" hidden name="id" value="<?php echo e($section->id); ?>">
                                    </div>
                                    <div class="form-group mb-3">
                                      <label for="">Section Description</label>
                                      <textarea name="section_desc" class="form-control"><?php echo e($section->section_desc); ?></textarea>
                                      <small>(If you want to hide this. Leave Empty this field.)</small>
                                    </div>
                                    <div class="form-group mb-3">
                                      <label class="form-label">Status</label>
                                      <select name="status" class="form-control" required>
                                        <option value="1" <?php if($section->status == '1'): ?> selected <?php endif; ?>>Active</option>
                                        <option value="0" <?php if($section->status == '0'): ?> selected <?php endif; ?>>Inactive</option>
                                      </select>
                                    </div>
                                    <button class="btn btn-primary updateHomeSection" type="button">Update</button>
                                  </form>
                                </div>
                              </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                            
                            
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/image-uploader.js')); ?>"></script>
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/admin/settings/homepage-settings.blade.php ENDPATH**/ ?>