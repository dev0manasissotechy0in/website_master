
<?php $__env->startSection('title','New Withdraw Requests : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> New Withdraw Request <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> New Withdraw Requests <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <form id="createWithdraw" class="border p-4 pt-5 position-relative" method="POST">
                    <h3>Submit New Withdraw Request</h3>
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-3">
                        <label for="">Method</label>
                        <select name="method" class="form-control">
                            <option value="" selected disabled>Select Method</option>
                            <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?>(<?php echo e($row->charge); ?>%)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group mb-3">
                        <label for="">Amount</label>
                        <input type="number" name="amount" class="form-control">
                    </div>
                    <div class="mb-3">
                        <span>Available Balance : <?php echo e(cur_format()); ?><?php echo e(seller_balance(session()->get('user_sess'))); ?></span>
                    </div>
                    <input type="submit" class="btn" value="Submit">
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/frontend/js/product.js')); ?>"></script>
<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $(function(){
        $('.product-images').imageUploader({
            imagesInputName: 'images',
            'label': 'Drag & Drop files here or click to browse' 
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/create-withdraw-request.blade.php ENDPATH**/ ?>