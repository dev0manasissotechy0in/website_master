<section id="page-header" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2><?php echo e($title); ?></h2>
                <ol class="breadcrumb justify-content-center">
                    <?php $__currentLoopData = $breadcrumb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="breadcrumb-item"><a href="<?php echo e(url($value)); ?>"><?php echo e($key); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="breadcrumb-item active"><?php echo e($active); ?></li>
                </ol>
            </div>
        </div>
    </div>
</section><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/public/layout/page-header.blade.php ENDPATH**/ ?>