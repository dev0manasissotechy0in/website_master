
<?php $__env->startSection('title','My Cart : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> My Cart <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> My Cart <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if($products->isNotEmpty()): ?>
                <form action="<?php echo e(url('user/checkout')); ?>">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>S.No.</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Product Price</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=0; $total = 0; ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; $total += $product->price; ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td>
                                <?php if($product->image != ''): ?>
                                <img src="<?php echo e(asset('public/products/default.jpg')); ?>" alt="" width="50px">
                                <?php else: ?>
                                <img src="<?php echo e(asset('public/products/'.$product->thumbnail)); ?>" alt="" width="50px">
                                <?php endif; ?>
                                <input type="text" hidden name="item[]" value="<?php echo e($product->id); ?>">
                            </td>
                            <td><?php echo e($product->title); ?></td>
                            <td><?php echo e(cur_format()); ?><?php echo e($product->price); ?></td>
                            <td>
                                <button type="button" data-id="<?php echo e($product->id); ?>" class="btn remove-cart"><i class="bi bi-x"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th colspan="3">Grand Total</th>
                            <th><?php echo e(cur_format()); ?><?php echo e($total); ?></th>
                            <th colspan="2"></th>
                        </tr>
                    </tbody>
                </table>
                <div class="d-flex justify-content-between">
                    <a href="<?php echo e(url('all-products')); ?>" class="btn">Continue Shopping</a>
                    <input type="submit" class="btn" value="Go To Checkout"/>
                </div>
                </form>
                <?php else: ?>
                <div class="text-center">
                    <h3>No Products Found in Cart</h3>
                    <a href="<?php echo e(url('/')); ?>" class="btn">Add Products</a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/frontend/js/product.js')); ?>"></script>
<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $(function(){
        $('.product-images').imageUploader({
            imagesInputName: 'images',
            'label': 'Drag & Drop files here or click to browse' 
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/user-cart.blade.php ENDPATH**/ ?>