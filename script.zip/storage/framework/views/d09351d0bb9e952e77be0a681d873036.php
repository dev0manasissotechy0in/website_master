
<?php $__env->startSection('title','Blog Category : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/assets/vendor/simple-datatables/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <?php $__env->startComponent('admin.partials.page-head',['breadcrumb'=>['Dashboard'=>'/admin/dashboard','Blog Category'=>'admin/blog-category']]); ?>
        <?php $__env->slot('title'); ?> Edit Blog Category <?php $__env->endSlot(); ?>
        <?php $__env->slot('add_btn'); ?> <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Edit <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body py-3">
                        
                        <form class="g-3 needs-validation" id="updateBlogCategory">
                          <?php echo csrf_field(); ?>
                          <?php echo e(method_field('PUT')); ?>

                            <div class="form-group mb-3">
                              <label class="form-label">Name</label>
                              <input type="text" class="form-control" name="category_name" value="<?php echo e($category->name); ?>" required>
                              <input type="text" hidden class="id" value="<?php echo e($category->id); ?>">
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Category Slug</label>
                              <input type="text" class="form-control" name="category_slug" value="<?php echo e($category->slug); ?>">
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Seo Title</label>
                              <input type="text" class="form-control" name="seo_title" value="<?php echo e($category->page_title); ?>" />
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Seo Description</label>
                              <textarea name="seo_desc" class="form-control"><?php echo e($category->page_desc); ?></textarea>
                            </div>
                            <div class="col-12">
                              <button class="btn btn-primary" type="submit">Update</button>
                            </div>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.validate.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/admin/blog/edit-category.blade.php ENDPATH**/ ?>