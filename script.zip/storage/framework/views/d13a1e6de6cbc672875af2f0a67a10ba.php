<!-- Vendor JS Files -->
    
    <script src="<?php echo e(asset('public/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
    
    
    
    
    <script src="<?php echo e(asset('public/assets/vendor/tinymce/tinymce.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/sweetalert2.min.js')); ?>"></script>
    
    <?php echo $__env->yieldContent('pageJsScripts'); ?>
    <!-- Template Main JS File -->
    <script src="<?php echo e(asset('public/assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('public/assets/js/action.js')); ?>"></script>
    <input type="text" class="site-url" value="<?php echo e(url('/')); ?>"><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/admin/partials/script.blade.php ENDPATH**/ ?>