
<?php $__env->startSection('title','View Order : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datatables.net-bs5/1.13.8/dataTables.bootstrap5.min.css" />
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <?php $__env->startComponent('admin.partials.page-head',['breadcrumb'=>['Dashboard'=>'/admin/dashboard','Orders'=>'/admin/orders']]); ?>
        <?php $__env->slot('title'); ?> Order Detail <?php $__env->endSlot(); ?>
        <?php $__env->slot('add_btn'); ?> <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Order Detail <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Order Details</h5>
                    </div>
                    <div class="card-body py-4">
                        <table class="table table-bordered">
                            <tr>
                                <th>Order No.</th>
                                <td><?php echo e($order->id); ?></td>
                            </tr>
                            <tr>
                                <th>Order Date</th>
                                <td><?php echo e(date('d M, Y',strtotime($order->created_at))); ?></td>
                            </tr>
                            <tr>
                                <th>Order User</th>
                                <td><?php echo e($order->order_user->name); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h5>Products</h5>
                    </div>
                    <div class="card-body py-4">
                        <table class="table table-bordered">
                            <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->product_name->title); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h5>Payment Details</h5>
                    </div>
                    <div class="card-body py-4">
                        <table class="table table-bordered">
                            <tr>
                                <th>Payment ID</th>
                                <td><?php echo e($order->pay_id); ?></td>
                            </tr>
                            <tr>
                                <th>Payment Method</th>
                                <td><?php echo e($order->pay_method); ?></td>
                            </tr>
                            <tr>
                                <th>Amount</th>
                                <td><?php echo e(cur_format()); ?><?php echo e($order->amount); ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/admin/orders/view.blade.php ENDPATH**/ ?>