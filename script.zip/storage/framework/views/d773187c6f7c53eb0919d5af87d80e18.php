
<?php $__env->startSection('title','Edit Product : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/image-uploader.css')); ?>">
<!-- Tokenfield for Bootstrap-->
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/tokenfield.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/trumbowyg.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <?php $__env->startComponent('admin.partials.page-head',['breadcrumb'=>['Dashboard'=>'/admin/dashboard','Products'=>'admin/products']]); ?>
        <?php $__env->slot('title'); ?> Edit Product <?php $__env->endSlot(); ?>
        <?php $__env->slot('add_btn'); ?> <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Edit <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body py-3">
                        <form class="g-3 needs-validation" id="updateProduct">
                          <?php echo csrf_field(); ?>
                          <?php echo e(method_field('PUT')); ?>

                            <div class="form-group mb-3">
                              <label class="form-label">Title</label>
                              <input type="text" class="form-control" name="product_title" value="<?php echo e($product->title); ?>" required>
                              <input type="text" hidden class="id" value="<?php echo e($product->id); ?>">
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Slug</label>
                              <input type="text" class="form-control" name="product_slug" value="<?php echo e($product->slug); ?>" required>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Category</label>
                              <select name="category" id="category" class="form-control">
                                <option value="" selected disabled>Select Category</option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $selected = ($cat->id == $product->category) ? 'selected' : '';  ?>
                                <option value="<?php echo e($cat->id); ?>"  <?php echo e($selected); ?>  ><?php echo e($cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Sub Category</label>
                              <select name="sub_category" id="sub-category" class="form-control">
                                <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $selected = ($sub_cat->id == $product->sub_category) ? 'selected' : '';  ?>
                                <option value="<?php echo e($sub_cat->id); ?>"  <?php echo e($selected); ?>  ><?php echo e($sub_cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Tags</label>
                              <?php
                              $tags_id = array_filter(explode(',',$product->tags));
                              $tag_names = '';
                              ?>
                              <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if(in_array($tag->id,$tags_id)): ?>
                                    <?php $tag_names == ''? '' : $tag_names.=',';  ?>
                                      <?php $tag_names .= $tag->name; ?>
                                  <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <input id="tokenfield" type="text" class="form-control" name="tags" value="<?php echo e($tag_names); ?>" placeholder="Type and hit enter to add a tag"/>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Price</label>
                              <input type="number" class="form-control" min="0" name="price" value="<?php echo e($product->price); ?>" />
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Thumbnail</label>
                              <input type="file" name="thumb" class="form-control" onChange="readURL(this);" />
                              <?php if($product->thumbnail != ''): ?>
                              <img id="image" src="<?php echo e(asset('public/products/'.$product->thumbnail)); ?>" width="100px">
                              <?php else: ?>
                              <img id="image" src="<?php echo e(asset('public/products/default.jpg')); ?>" width="100px">
                              <?php endif; ?>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Images</label>
                              <div class="product-images"></div>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Description</label>
                              <textarea name="desc" class="tinymce-editor"><?php echo $product->desc; ?></textarea>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Preview Link</label>
                              <input type="text" class="form-control" name="preview_link" value="<?php echo e($product->preview_link); ?>" />
                            </div>
                            <?php if($product->user == '1'): ?>
                            <div class="form-group mb-3">
                              <label class="form-label">Downloadable File (zip)</label>
                              <input type="file" name="download_file" class="form-control">
                              <input type="file" name="old_file" hidden value="<?php echo e($product->download_file); ?>"/>
                            </div>
                            <?php else: ?>
                            <div class="form-group mb-3">
                              <label class="form-label">Downloadable File (zip)</label>
                              <a href="<?php echo e(url('product/'.$product->slug.'/download')); ?>" class="btn mb-2 btn-primary"><i class="bi bi-download"></i> Download</a>
                              <input type="file" name="old_file" hidden value="<?php echo e($product->download_file); ?>"/>
                            </div>
                            <?php endif; ?>
                            <div class="form-group mb-3">
                              <label class="form-label">Featured</label>
                              <select name="featured" class="form-control">
                                <option value="1" <?php if($product->featured == '1'): ?> selected  <?php endif; ?>>Yes</option>
                                <option value="0" <?php if($product->featured == '0'): ?> selected  <?php endif; ?>>No</option>
                              </select>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Approved</label>
                              <select name="approve" class="form-control">
                                <option value="1" <?php if($product->approved == '1'): ?> selected  <?php endif; ?>>Yes</option>
                                <option value="0" <?php if($product->approved == '0'): ?> selected  <?php endif; ?>>No</option>
                              </select>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Status</label>
                              <select name="status" class="form-control">
                                <option value="1" <?php if($product->status == '1'): ?> selected <?php endif; ?>>Active</option>
                                <option value="0" <?php if($product->status == '0'): ?> selected <?php endif; ?>>Inactive</option>
                                <option value="2" <?php if($product->status == '2'): ?> selected <?php endif; ?>>Hidden</option>
                              </select>
                            </div>
                            <div class="col-12">
                              <button class="btn btn-primary" type="submit">Update</button>
                            </div>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->
<?php
$images = array_filter(explode(',',$product->images));
$images_array = [];
for($i=0;$i<count($images);$i++){
    $g = (object) array('id'=>$i+1,'src'=>asset('public/products/'.$images[$i]));
    array_push($images_array,$g);
}

?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/image-uploader.js')); ?>"></script>
<!-- Tokenfield Js -->
<script src="<?php echo e(asset('public/assets/js/tokenfield.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $(function () {

        var preloaded = <?php echo json_encode($images_array); ?>;

        $('.product-images').imageUploader({
            preloaded: preloaded,
            imagesInputName: 'images',
            'label': 'Drag and Drop',
            preloadedInputName: 'old',
            maxFiles: 10,
            maxSize: 2 * 1024 * 1024,
        });

        $('#tokenfield').tokenfield({
          autocomplete: {
              delay: 100
          },
          showAutocompleteOnFocus: false
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>