
<?php $__env->startSection('title','Edit Product Review : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <?php $__env->startComponent('admin.partials.page-head',['breadcrumb'=>['Dashboard'=>'/admin/dashboard','Product Reviews'=>'admin/product-reviews']]); ?>
        <?php $__env->slot('title'); ?> Edit Product Review <?php $__env->endSlot(); ?>
        <?php $__env->slot('add_btn'); ?> <?php $__env->endSlot(); ?>
        <?php $__env->slot('active'); ?> Edit <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
    <section class="section">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body py-3">
                        <form class="g-3 needs-validation" id="updateProductReview">
                          <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <h5>Product : <?php echo e($review->title); ?></h5>
                            </div>
                            <div class="mb-3">
                                <h5>User : <?php echo e($review->name); ?></h5>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Rating</label>
                              <input type="number" class="form-control" name="rating" min="0" max="5" value="<?php echo e($review->rating); ?>" required>
                              <input type="text" hidden class="id" value="<?php echo e($review->id); ?>">
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Feedback</label>
                              <textarea name="feedback" class="form-control"><?php echo e($review->feedback); ?></textarea>
                            </div>
                            <div class="form-group mb-3">
                              <label class="form-label">Status</label>
                              <select name="status" class="form-control">
                                <option value="1" <?php if($review->status == '1'): ?> selected <?php endif; ?>>Approve</option>
                                <option value="0" <?php if($review->status == '0'): ?> selected <?php endif; ?>>Pending</option>
                              </select>
                            </div>
                            <div class="col-12">
                              <button class="btn btn-primary" type="submit">Update</button>
                            </div>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main><!-- End #main -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/image-uploader.js')); ?>"></script>
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/admin/reviews/edit.blade.php ENDPATH**/ ?>