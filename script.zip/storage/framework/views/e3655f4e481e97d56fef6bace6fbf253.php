<div class="col-md-4 mb-4">
    <div class="blog-grid h-100">
        <a href="<?php echo e(url('blog/'.$blog->slug)); ?>" class="blog-img d-block">
            <?php if($blog->image != ''): ?>
            <img src="<?php echo e(asset('public/blogs/'.$blog->image)); ?>" class="w-100" alt="">
            <?php else: ?>
            <img src="<?php echo e(asset('public/blogs/default.png')); ?>" class="w-100" alt="">
            <?php endif; ?>
        </a>
        <div class="blog-content mt-auto">
            <div class="d-flex justify-content-between mb-2">
                <span><i class="bi bi-calendar"></i> <?php echo e(date('M-d-Y',strtotime($blog->created_at))); ?></span>
                <span><a href="<?php echo e(url('blogs/c/'.$blog->cat_name->slug)); ?>"><?php echo e($blog->cat_name->name); ?></a></span>
            </div>
            <h3 class="title"><a href="<?php echo e(url('blog/'.$blog->slug)); ?>"><?php echo e(substr($blog->title,0,60).'...'); ?></a></h3>
        </div>
    </div>
</div><?php /**PATH D:\c files\Xampp\htdocs\manasissotechy.in_official_code\script\resources\views/public/partials/blog.blade.php ENDPATH**/ ?>