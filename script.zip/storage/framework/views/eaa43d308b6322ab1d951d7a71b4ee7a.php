
<?php $__env->startSection('title','Payment Success : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> Payment Success <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> payment success <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2 text-center">
                <h4>Payment Successfull</h4>
                <a href="<?php echo e(url('my-downloads')); ?>" class="btn">Go To Downloads</a>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/payment-success.blade.php ENDPATH**/ ?>