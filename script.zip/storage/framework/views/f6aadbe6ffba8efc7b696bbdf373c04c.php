
<?php $__env->startSection('title','Reset Password : '); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> Change Password <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> Change Password <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-4">
                <form id="change-password" class="border p-4 pt-5 position-relative" method="POST">
                    <?php echo csrf_field(); ?>
                    <h3>Change Password!!!</h3>
                    <div class="form-group mb-3">
                        <label for="">Current Password</label>
                        <input type="password" class="form-control" name="old_password" />
                    </div>
                    <div class="form-group mb-3">
                        <label for="">New Password</label>
                        <input type="password" id="password" class="form-control" name="password" />
                    </div>
                    <div class="form-group mb-3">
                        <label for="">Confirm Password</label>
                        <input type="password" class="form-control" name="confirm_password" />
                    </div>
                    <div class="d-flex justify-content-between mb-4">
                        <input type="submit" class="btn" value="Update" />
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/change-password.blade.php ENDPATH**/ ?>