
<?php $__env->startSection('title','Edit Product : '); ?>
<?php $__env->startSection('pageStyleLinks'); ?>
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/image-uploader.css')); ?>">
<!-- Tokenfield for Bootstrap-->
<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/tokenfield.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/trumbowyg.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startComponent('public.layout.page-header',['breadcrumb'=>['Home'=>'/']]); ?>
<?php $__env->slot('title'); ?> Edit Product <?php $__env->endSlot(); ?>
<?php $__env->slot('active'); ?> Edit product <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<section id="page-content" class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form id="update-product" class="border p-4 pt-5 position-relative" method="POST">
                    <?php echo csrf_field(); ?>
                    <h3>Edit Product!!!</h3>
                    <div class="row">
                        <div class="col-md-9">
                            <div class="form-group mb-3">
                                <label for="">Product Title : <b><?php echo e($product->title); ?></b></label>
                            </div>
                            <div class="form-group mb-3">
                                <label for="">Category : <b><?php echo e($product->title); ?></b></label>
                            </div>
                            <div class="form-group mb-3">
                                <label for="">Sub Category : <b><?php echo e($product->title); ?></b></label>
                            </div>
                            <div class="form-group mb-3">
                                <label for="">Description</label>
                                <textarea name="desc" id="editor" class="form-control" cols="30" rows="10"><?php echo $product->desc; ?></textarea>
                            </div>
                            <div class="form-group mb-3">
                                <label for="">Images</label>
                                <div class="product-images"></div>
                            </div>
                            <div class="form-group mb-3">
                                <label for="">Preview Link</label>
                                <input type="text" name="preview_link" class="form-control" value="<?php echo e($product->preview_link); ?>" />
                            </div>
                            
                            <div class="form-group mb-3">
                                <label for="">Tags</label>
                                <?php
                                $tags_id = array_filter(explode(',',$product->tags));
                                $tag_names = '';
                                ?>
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(in_array($tag->id,$tags_id)): ?>
                                        <?php $tag_names == ''? '' : $tag_names.=',';  ?>
                                        <?php $tag_names .= $tag->name; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="text" name="tags" value="<?php echo e($tag_names); ?>" id="tokenfield" class="form-control" />
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group mb-3">
                                <label for="">Thumbnail</label>
                                <input type="file" class="form-control" name="thumb" onChange="readURL(this);" />
                                <?php if($product->thumbnail != ''): ?>
                                <img src="<?php echo e(url('public/products/'.$product->thumbnail)); ?>" id="image" class="w-100 mt-4" alt="">
                                <?php else: ?>
                                <img src="<?php echo e(url('public/products/default.jpg')); ?>" id="image" class="w-100 mt-4" alt="">
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <div class="form-group mb-3">
                                    <label for="">If you want to change Downloadable File (zip file)</label>
                                    <input type="file" name="download_file" class="form-control" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="form-group mb-3">
                                    <label for="">Status</label>
                                    <select name="status" class="form-control">
                                        <option value="1" <?php if($product->status == '1'): ?> selected <?php endif; ?>>Active</option>
                                        <option value="0" <?php if($product->status == '0'): ?> selected <?php endif; ?>>Inactive</option>
                                    </select>
                                    <input type="text" hidden class="slug" value="<?php echo e($product->slug); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <input type="submit" class="btn" value="Update" />
                </form>
            </div>
        </div>
    </div>
</section>
<?php
$images = array_filter(explode(',',$product->images));
$images_array = [];
for($i=0;$i<count($images);$i++){
    $g = (object) array('id'=>$i+1,'src'=>asset('public/products/'.$images[$i]));
    array_push($images_array,$g);
}

?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageJsScripts'); ?>
<script src="<?php echo e(asset('public/frontend/js/product.js')); ?>"></script>
<!-- Tokenfield Js -->
<script src="<?php echo e(asset('public/assets/js/tokenfield.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.4/jquery-ui.min.js"></script>
<script src="<?php echo e(asset('public/frontend/js/trumbowyg.min.js')); ?>"></script>
<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $('#image').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
    }
    $(function(){
        $('#editor').trumbowyg();

        var preloaded = <?php echo json_encode($images_array); ?>;

        $('.product-images').imageUploader({
            preloaded: preloaded,
            imagesInputName: 'images',
            'label': 'Drag and Drop',
            preloadedInputName: 'old',
            maxFiles: 10,
            maxSize: 2 * 1024 * 1024,
        });

        $('#tokenfield').tokenfield({
        autocomplete: {
            delay: 100
        },
        showAutocompleteOnFocus: false
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\digital-sell-yb\resources\views/public/edit-product.blade.php ENDPATH**/ ?>